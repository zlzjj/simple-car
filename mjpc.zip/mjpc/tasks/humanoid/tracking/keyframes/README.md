* The data in this directory was obtained from mocap.cs.cmu.edu.
* The database was created with funding from NSF EIA-0196217.
